/*****************************************************************************
* | File      	:   Readme_CN.txt
* | Author      :   Waveshare team
* | Function    :   Help with use
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2020-02-19
* | Info        :   在这里提供一个中文版本的使用文档，以便你的快速使用
******************************************************************************/
这个文件是帮助您使用本例程。

1.基本信息：
本例程是基于Arduino进行开发的，例程均在E-Paper ESP32 Driver Board上进行了验证;

2.基本使用：
    将整个esp32-waveshare-epd文件夹复制到Arduino安装路径下\hardware\espressif\esp32\libraries文件夹中
    然后打开Arduino IDE,在文件=》示例=》找到 wareshare-e-Paper，打开对应的demo，下载到E-Paper ESP32 Driver Board即可。
