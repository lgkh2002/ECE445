# ECE445

This is the Git repository for the JargonJolt ECE445 project by Daniel Chamoun, Luke Hartmann, and Nan Kang.
